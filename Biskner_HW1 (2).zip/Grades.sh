#!/bin/bash

# Blake Biskner - Recitation 107
if [ $# -ne 1 ]; then
	echo 'Usage: Grades.sh filename' #Prints usage statement
else
	sort -k3,3 -k2,2 -k1,1g $1| # Pipes sorted data to while loop
	while IFS=" " read -r ID FN LN S1 S2 S3
	do
		av=$(((S1+S2+S3)/3)) #calculates average
		echo "$av[$ID]$LN, $FN" #prints desired output for each line
	done
fi
