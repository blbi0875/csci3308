#!/bin/bash
# Blake Biskner - Recitation 107

if [ $# -ne 1 ];then
	echo 'Usage: GradesAwk.sh filename' #Usage statement if no CLA
else
	sort -k3,3f -k2,2f -k1,1g $1| #Sorts data and pipes to awk
	awk '
	{
	sum=0;
		for ( i=4; i<=NF; i=i+1)
		{
			sum=sum+$i;
		}
		av=int(sum/(NF-3))
		print av"["$1"]" $3","" "$2;
	}'
fi
