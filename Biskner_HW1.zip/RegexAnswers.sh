# Blake Biskner- Recitation 107

if [ $# -ne 1 ]; then
	echo 'Usage: RegexAnswers.sh filename'
else
	# 1. Lines ending with number
	egrep *[0-9]$ $1|wc -l
	# 2. Lines that do not start with vowel
	egrep ^[^AEIOUYaeiouy] $1|wc -l
	# 3. Twelve letter lines
	egrep ^[A-Za-z]{12}$ $1|wc -l
	# 4. Phone numbers in data
	egrep ^[0-9]{3}-[0-9]{3}-[0-9]{4}$ $1|wc -l
	# 5. Boulder phone numbers
	egrep ^303-[0-9]{3}-[0-9]{4}$ $1|wc -l
	# 6. Begin with vowel and end with number
	egrep ^[AEIOUYaeiouy]*[0-9]$ $1|wc -l
	# 7. Geocities email
	egrep *geocities\.com$ $1|wc -l
	# 8. Incoorect email
	egrep *@[^0-9A-Za-z\-]\.[^a-z]{3}$ $1|wc -l
fi
